public class WeeklyRentalStrategy implements RentalStrategy {
    private double weeklyRate;

    public WeeklyRentalStrategy(double weeklyRate) {
        this.weeklyRate = weeklyRate;
    }

    @Override
    public RentalReceipt rent(Car car, int weeks) {
        double totalPrice = weeklyRate * weeks;
        return new RentalReceipt(car, weeks * 7, totalPrice);
    }
}
