public class Main {
    public static void main(String[] args) {
        CarRentalSystem carRentalSystem = CarRentalSystem.getInstance();

        Car car1 = new Car("Toyota Camry", "014PVL|14");
        Car car2 = new Car("Chevrolet Cobalt", "666ZLO|13");

        // Use DailyRentalStrategy
        RentalStrategy dailyRentalStrategy = new DailyRentalStrategy(50.0);
        RentalReceipt receipt1 = carRentalSystem.rentCar(car1, dailyRentalStrategy, 3);

        // Use WeeklyRentalStrategy
        RentalStrategy weeklyRentalStrategy = new WeeklyRentalStrategy(250.0);
        RentalReceipt receipt2 = carRentalSystem.rentCar(car1, weeklyRentalStrategy, 2);

        // Display rental receipts
        displayReceipt(receipt1);
        displayReceipt(receipt2);
    }

    private static void displayReceipt(RentalReceipt receipt) {
        System.out.println("Rental Receipt:");
        System.out.println("Model: " + receipt.getCar().getModel());
        System.out.println("License Plate: " + receipt.getCar().getLicensePlate());
        System.out.println("Rental Duration: " + receipt.getRentalDuration() + " days");
        System.out.println("Total Price: $" + receipt.getTotalPrice());
        System.out.println();
    }
}
