public interface RentalStrategy {
    RentalReceipt rent(Car car, int days);
}
